﻿using Model.CodificacaoTipoVerbalizacaoViewModel;
using Model.FiltrosModel;
using Model.NPSSegmentoModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.InterfacesDashboard
{
    public interface IDashboard
    {
        Task<List<NPSSegmentoModel>> ObterTipoSegmentoNPS(FiltroPadrao filtroPadrao);
        Task<List<ComboAtributosModel>> ObterComboAtributos();

        Task<List<CodificacaoTipoVerbalizacaoModel>> ObterCodificacaoTipoVerbalizacaoModel();
    }
}
