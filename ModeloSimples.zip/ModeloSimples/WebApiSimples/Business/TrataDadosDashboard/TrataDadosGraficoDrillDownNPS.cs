﻿using Model.NPSSegmentoModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.TrataDadosDashboard
{
    public class TrataDadosGraficoDrillDownNPS
    {
        public static List<NPSSegmentoModel> TrataDados(List<BaseSegmentoModel> listaBaseSegmentoModel)
        {
            var retorno = new List<NPSSegmentoModel>();

            foreach (var item in listaBaseSegmentoModel)
            {

                if (!retorno.Any(c => c.Codigo == item.Codigo))
                {
                    var primeiraColuna = listaBaseSegmentoModel.FirstOrDefault(a => a.Codigo == item.Codigo);
                    var segundaColuna = listaBaseSegmentoModel.LastOrDefault(a => a.Codigo == item.Codigo);

                    if (primeiraColuna != null && segundaColuna != null)
                    {
                        retorno.Add(new NPSSegmentoModel
                        {
                            DescSegmento = primeiraColuna.Descricao,

                            DescPeriodo = primeiraColuna.DescPeriodo,
                            NPS = primeiraColuna.NPS,
                            Detratores = primeiraColuna.Detratores,
                            Neutros = primeiraColuna.Neutros,
                            Promotores = primeiraColuna.Promotores,
                            Base = primeiraColuna.Base,

                            DescPeriodo_Direita = segundaColuna.DescPeriodo,
                            NPS_Direita = segundaColuna.NPS,
                            Detratores_Direita = segundaColuna.Detratores,
                            Neutros_Direita = segundaColuna.Neutros,
                            Promotores_Direita = segundaColuna.Promotores,
                            Base_Direita = segundaColuna.Base,
                            Codigo = primeiraColuna.Codigo
                        });
                    }

                }



            }
            return retorno;

        }

    }
}
