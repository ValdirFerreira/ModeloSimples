﻿using Microsoft.Extensions.Configuration;
using System;

namespace ConexaoBase
{
    public class DefaultConnection
    {

        public string DbName { get; set; }

        public bool IsProd { get; set; }

        public DefaultConnection(IConfiguration configuration)
        {
            Configuration = configuration;
            DbName = Configuration.GetConnectionString("DbName");
            IsProd = Convert.ToBoolean(Configuration.GetConnectionString("IsProd"));

        }

        public IConfiguration Configuration { get; }

        public string GetStringConectionConfig()
        {
            // no método RetornaConexaoSSRS Microsoft.VisualBasic depende a atualização para a versão 10.30 para funcionar aqui
            //SisConn.clsAcessoBanco clsAcessoBanco = new SisConn.clsAcessoBanco();
            //var strCon = clsAcessoBanco.RetornaConexaoSSRS(DbName, IsProd);
            //return strCon;

            return "Data Source=192.168.19.3;Initial Catalog=BancoBrasil;user=ipsosbrasil;pwd=08ABA0AB5974-FF5A-D364-181D-EC880B4B; Pooling=false;";
           
        }


    }
}
