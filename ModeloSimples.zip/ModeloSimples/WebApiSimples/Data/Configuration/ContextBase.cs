﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Model.CodificacaoFatorModel;
using Model.CodificacaoTipoVerbalizacaoViewModel;
using Model.NPSSegmentoModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Configuration
{
    public class ContextBase : DbContext
    {

        public IConfigurationRoot Configuration { get; set; }

        public ContextBase(DbContextOptions<ContextBase> options) : base(options)
        {

        }

        public DbSet<BaseSegmentoModel> BaseSegmentoModel { get; set; }
        public DbSet<ComboAtributosModel> ComboAtributosModel { get; set; }
        public DbSet<CodificacaoTipoVerbalizacaoModel> CodificacaoTipoVerbalizacaoModel { get; set; }
        public DbSet<CodificacaoFatorModel> CodificacaoFatorModel { get; set; }



        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // SE NÇÃO ESTIVER CONFIGURADO VIA : appsettings.json
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(GetStringConectionConfig());
                base.OnConfiguring(optionsBuilder);
            }
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {

            builder.Entity<ComboAtributosModel>().HasNoKey().ToView(null);
            builder.Entity<BaseSegmentoModel>().HasNoKey().ToView(null);
            base.OnModelCreating(builder);
        }

        /// <summary>
        /// SE OUVER NECESSIDADE DE INSERIR A STRING DE CONEXÃO MANUAL
        /// </summary>
        /// <returns></returns>
        private string GetStringConectionConfig()
        {

            //var DbName = ConfigurationManager.AppSettings.Get("ConnectionStrings");
            //var IsProd = ConfigurationManager.AppSettings.Get("IsProd");

            //var retorno = DefaultConnection.GetStringConectionConfig(Configuration.GetConnectionString(DbName), Convert.ToBoolean(Configuration.GetConnectionString(IsProd)));
            //return retorno;
            return "Data Source=192.168.19.3;Initial Catalog=BancoBrasil;user=ipsosbrasil;pwd=08ABA0AB5974-FF5A-D364-181D-EC880B4B; Pooling=false;";
        }


    }
}
