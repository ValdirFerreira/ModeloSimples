﻿using Business.DisposableGenerics;
using Business.InterfacesDashboard;
using Business.Log;
using Business.TrataDadosDashboard;
using Business.TrataDadosFiltros;
using ConexaoBase;
using Dapper;
using Data.Configuration;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Model.CodificacaoTipoVerbalizacaoViewModel;
using Model.FiltrosModel;
using Model.NPSSegmentoModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Repositories
{
    public class RepositoryDashboard : RepositoryDisposableGenerics, IDashboard
    {

        private readonly DbContextOptions<ContextBase> _optionsbuilder;
        public IConfiguration Configuration { get; }
        public DefaultConnection Conexao { get; set; }

        public RepositoryDashboard()
        {
            _optionsbuilder = new DbContextOptions<ContextBase>();
            Configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json")
                    .Build();
            Conexao = new DefaultConnection(Configuration);
        }


        /// <summary>
        /// ObterTipoSegmentoNPS
        /// </summary>
        /// <param name="filtroPadrao"></param>
        /// <returns></returns>
        public async Task<List<NPSSegmentoModel>> ObterTipoSegmentoNPS(FiltroPadrao filtroPadrao)
        {

            try
            {
                using (SqlConnection conexaoBD = new SqlConnection(Conexao.GetStringConectionConfig()))
                {
                    var param = TratadadosFiltroPadrao.TrataDadosFiltrosDrillDowNPS(filtroPadrao);
                    var retornoProcedure = conexaoBD.QueryAsync<BaseSegmentoModel>("sp_DrillDown_Linha1Bloco1_NPS", param, null, 300, System.Data.CommandType.StoredProcedure).Result.ToList();
                    var retorno = TrataDadosGraficoDrillDownNPS.TrataDados(retornoProcedure);

                    return await Task.FromResult(retorno);

                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
            }

            return new List<NPSSegmentoModel>();

        }

        /// <summary>
        /// ObterComboAtributos 
        /// </summary>
        /// <returns></returns>
        public async Task<List<ComboAtributosModel>> ObterComboAtributos()
        {
            try
            {
                using (SqlConnection conexaoBD = new SqlConnection(Conexao.GetStringConectionConfig()))
                {
                    var retornoProcedure = conexaoBD.QueryAsync<ComboAtributosModel>("sp_ComboAtributos", null, null, 300, System.Data.CommandType.StoredProcedure).Result.ToList();
                    return await Task.FromResult(retornoProcedure.OrderBy(a => a.DescItem).ToList());
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name, ex.Message);
            }
            return new List<ComboAtributosModel>();

        }

        /// <summary>
        ///  ObterCodificacaoTipoVerbalizacaoModel - Utilizando FRAMEWORK ( EXEMPLO DE JOIN )
        /// </summary>
        /// <returns></returns>
        public async Task<List<CodificacaoTipoVerbalizacaoModel>> ObterCodificacaoTipoVerbalizacaoModel()
        {
            using (var banco = new ContextBase(_optionsbuilder))
            {

                return await (from CV in banco.CodificacaoTipoVerbalizacaoModel
                              join CF in banco.CodificacaoFatorModel on CV.Id equals CF.CodAtributo
                              select CV).ToListAsync();

                // return await banco.CodificacaoTipoVerbalizacaoModel.ToListAsync();
            }
        }
    }
}
