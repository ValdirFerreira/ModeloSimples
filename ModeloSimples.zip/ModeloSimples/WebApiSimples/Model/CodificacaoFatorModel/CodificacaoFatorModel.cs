﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.CodificacaoFatorModel
{
    [Table("tblCodificacaoFator")]
    public  class CodificacaoFatorModel
    {
        [Column("CodCodificacao")]
        public int Id { get; set; }

        [Column("CodAtributo")]
        public int CodAtributo { get; set; }
    }
}
