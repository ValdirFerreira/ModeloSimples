﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.CodificacaoTipoVerbalizacaoViewModel
{

    [Table("tblCodificacaoTipoVerbalizacao")]
    public  class CodificacaoTipoVerbalizacaoModel
    {
        [Key]
        [Column("CodTipoVerbalizacao")]
        public int Id { get; set; }

        [Column("DescTipoVerbalizacao")]
        public string DescTipoVerbalizacao { get; set; }
    }
}
