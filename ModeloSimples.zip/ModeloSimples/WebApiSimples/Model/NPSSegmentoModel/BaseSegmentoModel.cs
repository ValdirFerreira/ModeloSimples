﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.NPSSegmentoModel
{
    public class BaseSegmentoModel
    {
        public string DescPeriodo { get; set; }
        public int Codigo { get; set; }
        public string Descricao { get; set; }
        public float Detratores { get; set; }
        public float Neutros { get; set; }
        public float Promotores { get; set; }
        public float NPS { get; set; }
        public float Base { get; set; }
        public int Ordem { get; set; }
        public int AnoMes { get; set; }

    }
}
