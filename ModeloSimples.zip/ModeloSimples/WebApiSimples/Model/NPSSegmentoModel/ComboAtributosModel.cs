﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.NPSSegmentoModel
{
    public class ComboAtributosModel
    {
        public int IdItem { get; set; }
        public string DescItem { get; set; }

    }
}
