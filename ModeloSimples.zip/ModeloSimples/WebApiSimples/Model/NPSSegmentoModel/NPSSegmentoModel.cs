﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.NPSSegmentoModel
{
    public class NPSSegmentoModel
    {
        public string DescPeriodo { get; set; }
        public string DescSegmento { get; set; }
        public float Detratores { get; set; }
        public float Neutros { get; set; }
        public float Promotores { get; set; }
        public float NPS { get; set; }
        public float Base { get; set; }
        public float FlagPrevia { get; set; }
        public string DescPeriodo_Direita { get; set; }
        public float Detratores_Direita { get; set; }
        public float Neutros_Direita { get; set; }
        public float Promotores_Direita { get; set; }
        public float NPS_Direita { get; set; }
        public float Base_Direita { get; set; }
        public float FlagPrevia_Direita { get; set; }
        public int Codigo { get; set; }

    }
}
