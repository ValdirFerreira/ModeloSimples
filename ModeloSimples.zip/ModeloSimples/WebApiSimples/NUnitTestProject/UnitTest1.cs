using Business.InterfacesDashboard;
using Data.Repositories;
using NUnit.Framework;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace NUnitTestProject
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task Test_ObterCodificacaoTipoVerbalizacaoModel()
        {
            try
            {
                IDashboard _IDashboard = new RepositoryDashboard();

                var retorno = await _IDashboard.ObterCodificacaoTipoVerbalizacaoModel();

                Assert.IsTrue(retorno.Any());
            }
            catch (Exception)
            {

                Assert.Fail();
            }
        }
    }
}