﻿using Business.InterfacesDashboard;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Model.FiltrosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiSimples.Controllers
{
    public class DashBoardController : Controller
    {
        public readonly IDashboard _IDashboard;

        public DashBoardController(IDashboard IDashboard)
        {
            _IDashboard = IDashboard;
      
        }


        [HttpPost]
        [Route("ObterTipoSegmentoNPS")]
        public async Task<JsonResult> ObterTipoSegmentoNPS(FiltroPadrao filtroPadrao)
        {
            return Json(await _IDashboard.ObterTipoSegmentoNPS(filtroPadrao));
        }


        [HttpGet]
        [Route("ObterComboAtributos")]
        public async Task<IActionResult> ObterComboAtributos()
        {
            return Json(await _IDashboard.ObterComboAtributos());
        }


        [HttpGet]
        [Route("ObterCodificacaoTipoVerbalizacaoModel")]
        public async Task<IActionResult> ObterCodificacaoTipoVerbalizacaoModel()
        {
            return Json(await _IDashboard.ObterCodificacaoTipoVerbalizacaoModel());
        }


    }
}
